<script src="assets/javascript/app.js"></script>

</body>
</html>