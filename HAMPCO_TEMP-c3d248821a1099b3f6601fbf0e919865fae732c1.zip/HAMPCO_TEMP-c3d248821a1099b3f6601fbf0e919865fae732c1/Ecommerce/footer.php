</body>
</html>

<footer>

    <p>2025 HAMPCO! All rights reserved.</p>
  </div>