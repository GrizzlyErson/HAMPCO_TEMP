<?php require_once "header.php";?>


  <div class="carousel-pagination absolute bottom-3 end-0 start-0 flex justify-center gap-3"></div>
</div>

<div class="pt-24 px-4 max-w-4xl mx-auto">
    <h1 class="text-3xl font-bold mb-4">Welcome to the Page</h1>
    <p class="mb-6">Scroll down to see the sticky navbar in action. This content is just filler to demonstrate scrolling behavior.</p>
    <div class="space-y-6">
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel tincidunt...</p>
      <p>Aliquam erat volutpat. Curabitur nec lorem vel sapien facilisis tincidunt. Integer...</p>
      <p>Vivamus sit amet turpis nec sapien tincidunt fermentum. Suspendisse potenti. Nullam...</p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel tincidunt...</p>
      <p>Aliquam erat volutpat. Curabitur nec lorem vel sapien facilisis tincidunt. Integer...</p>
      <p>Vivamus sit amet turpis nec sapien tincidunt fermentum. Suspendisse potenti. Nullam...</p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel tincidunt...</p>
      <p>Aliquam erat volutpat. Curabitur nec lorem vel sapien facilisis tincidunt. Integer...</p>
      <p>Vivamus sit amet turpis nec sapien tincidunt fermentum. Suspendisse potenti. Nullam...</p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel tincidunt...</p>
      <p>Aliquam erat volutpat. Curabitur nec lorem vel sapien facilisis tincidunt. Integer...</p>
      <p>Vivamus sit amet turpis nec sapien tincidunt fermentum. Suspendisse potenti. Nullam...</p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel tincidunt...</p>
      <p>Aliquam erat volutpat. Curabitur nec lorem vel sapien facilisis tincidunt. Integer...</p>
      <p>Vivamus sit amet turpis nec sapien tincidunt fermentum. Suspendisse potenti. Nullam...</p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel tincidunt...</p>
      <p>Aliquam erat volutpat. Curabitur nec lorem vel sapien facilisis tincidunt. Integer...</p>
      <p>Vivamus sit amet turpis nec sapien tincidunt fermentum. Suspendisse potenti. Nullam...</p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel tincidunt...</p>
      <p>Aliquam erat volutpat. Curabitur nec lorem vel sapien facilisis tincidunt. Integer...</p>
      <p>Vivamus sit amet turpis nec sapien tincidunt fermentum. Suspendisse potenti. Nullam...</p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel tincidunt...</p>
      <p>Aliquam erat volutpat. Curabitur nec lorem vel sapien facilisis tincidunt. Integer...</p>
      <p>Vivamus sit amet turpis nec sapien tincidunt fermentum. Suspendisse potenti. Nullam...</p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel tincidunt...</p>
      <p>Aliquam erat volutpat. Curabitur nec lorem vel sapien facilisis tincidunt. Integer...</p>
      <p>Vivamus sit amet turpis nec sapien tincidunt fermentum. Suspendisse potenti. Nullam...</p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel tincidunt...</p>
      <p>Aliquam erat volutpat. Curabitur nec lorem vel sapien facilisis tincidunt. Integer...</p>
      <p>Vivamus sit amet turpis nec sapien tincidunt fermentum. Suspendisse potenti. Nullam...</p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel tincidunt...</p>
      <p>Aliquam erat volutpat. Curabitur nec lorem vel sapien facilisis tincidunt. Integer...</p>
      <p>Vivamus sit amet turpis nec sapien tincidunt fermentum. Suspendisse potenti. Nullam...</p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel tincidunt...</p>
      <p>Aliquam erat volutpat. Curabitur nec lorem vel sapien facilisis tincidunt. Integer...</p>
      <p>Vivamus sit amet turpis nec sapien tincidunt fermentum. Suspendisse potenti. Nullam...</p>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel tincidunt...</p>
      <p>Aliquam erat volutpat. Curabitur nec lorem vel sapien facilisis tincidunt. Integer...</p>
      <p>Vivamus sit amet turpis nec sapien tincidunt fermentum. Suspendisse potenti. Nullam...</p>
    </div>
  </div>
</div>