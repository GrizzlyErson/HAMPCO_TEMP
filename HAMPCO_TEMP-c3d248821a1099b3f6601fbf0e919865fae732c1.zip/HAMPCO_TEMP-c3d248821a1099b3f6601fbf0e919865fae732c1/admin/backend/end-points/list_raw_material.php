<?php 
require_once './backend/class.php';
$db = new global_class();

$fetch_all_materials = $db->fetch_all_materials();

if ($fetch_all_materials->num_rows > 0) {
    while ($row = $fetch_all_materials->fetch_assoc()) {
        $total_value = floatval($row['rm_quantity']) * floatval($row['unit_cost']);
?>
    <tr class="border-b border-gray-200 hover:bg-gray-50">
        <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($row['raw_materials_name']); ?></td>
        <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($row['category']); ?></td>
        <td class="py-3 px-6 text-left"><?php echo number_format($row['rm_quantity'], 2); ?></td>
        <td class="py-3 px-6 text-left">₱ <?php echo number_format(floatval($row['unit_cost']), 2); ?></td>
        <td class="py-3 px-6 text-left">₱ <?php echo number_format($total_value, 2); ?></td>
        <td class="py-3 px-6 text-left"><?php echo htmlspecialchars($row['supplier_name'] ?? '-'); ?></td>
        <td class="py-3 px-6 text-left" style="color: <?php echo strtolower($row['rm_status']) == 'available' ? 'green' : (strtolower($row['rm_status']) == 'not available' ? 'red' : 'orange'); ?>">
            <?php echo htmlspecialchars(ucfirst($row['rm_status'])); ?>
        </td>
        <td class="py-3 px-6 flex space-x-2">
        <div class="flex flex-col items-center">
            <button 
                style="margin-bottom: 5px;"
                type="button"
                class="updateRmBtn bg-green-500 hover:bg-green-600 text-white py-1 px-3 rounded-full text-xs flex items-center shadow"
                data-id="<?php echo htmlspecialchars($row['rmid']); ?>" 
                data-rm_name="<?php echo htmlspecialchars($row['raw_materials_name']); ?>"
                data-category="<?php if($row['category']=='') {echo htmlspecialchars("Not available");} else {echo htmlspecialchars($row['category']);}  ?>"
                data-rm_quantity="<?php echo htmlspecialchars($row['rm_quantity']); ?>"
                data-rm_unit="<?php echo htmlspecialchars($row['rm_unit']); ?>"
                data-unit_cost="<?php echo htmlspecialchars($row['unit_cost']); ?>"
                data-rm_status="<?php echo htmlspecialchars(ucfirst(strtolower($row['rm_status']))); ?>"
                data-supplier_name="<?php echo htmlspecialchars($row['supplier_name'] ?? ''); ?>"
            >
                <span class="material-icons text-sm mr-1">edit</span> Update
            </button>
            
            <button 
                type="button"
                class="deleteRmBtn bg-red-500 hover:bg-red-600 text-white py-1 px-3 rounded-full text-xs flex items-center shadow"
                data-id="<?php echo htmlspecialchars($row['rmid']); ?>" 
                data-rm_name="<?php echo htmlspecialchars($row['raw_materials_name']); ?>"
            >
                <span class="material-icons text-sm mr-1">delete</span> Remove
            </button>
        </div>
</td>
    </tr>
<?php
    }
} else {
?>
    <tr>
        <td colspan="8" class="py-3 px-6 text-center">No raw materials found.</td>
    </tr>
<?php
}
?>
