ALTER TABLE `user_member`
ADD COLUMN `id_number` VARCHAR(20) NOT NULL AFTER `password`; 